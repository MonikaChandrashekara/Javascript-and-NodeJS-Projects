
//CRUD operation : Create Read Update Delete
// const mongodb = require('mongodb')
// const MongoClient = mongodb.MongoClient

const {MongoClient, ObjectID} = require('mongodb')

const connectionURL ='mongodb://127.0.0.1:27017'
const databaseName ='task-manager'


// const id = new ObjectID()
// console.log(id)
// console.log(id.getTimestamp())
// console.log(id.id.length)
// console.log(id.toHexString().length)

MongoClient.connect(connectionURL,{useNewUrlParser:true},(error,client) =>{

    if(error)
    {
        return console.log('Unable to connect to the database!')
    }

    console.log('Conneceted Correctly!')

    const db = client.db(databaseName)

    // db.collection('users').insertOne({
    //     _id: id,
    //     name: 'Vikram',
    //     age: 27
    // },(error, result)=>{

    //     if(error){
            
    //         return console.log('Unable to insert user')
    //     }

    //     console.log(result.ops)
    // })


    // db.collection('users').insertMany([

    //     {
    //         name:'Rachel',
    //         age: 23
    //     },{
    //         name : 'Phoebe',
    //         age: 25
    //     }
    // ], (error, result)=>{

    //     if(error){
    //         return console.log('Unable to insert user documents')
    //     }

    //     console.log(result.ops)
    // })



    // db.collection('tasks').insertMany([
    //     {
    //         description: 'Grocerry Shopping',
    //         completed: true
    //     },{
    //         description: 'Solve leetcode',
    //         completed: false
    //     },{
    //         description: 'Workout',
    //         completed:false
    //     }
    // ], (error, result)=>{

    //     if(error){
    //         return console.log('Unable to insert task documents!')
    //     }

    //     console.log(result.ops)
    // })



    // db.collection('users').findOne({_id: new ObjectID("5e73c3357e58a5513c8df067")}, (error, user)=>{

    //    if(error){
    //       return  console.log('Unable to fetch user!')
    //    }

    //    console.log(user)
    // })


    // db.collection('users').find({age:24}).toArray((error, users) =>{

    //     console.log(users)
    // })


    
    // db.collection('users').find({age:24}).count((error, count) =>{

    //     console.log(count)
    // })



    // db.collection('tasks').findOne({_id: new ObjectID("5e73c47e2182c766dccfd786")}, (error, task)=>{

    //     if(error){
    //         return console.log('Unable to fetch!')
    //     }

    //     console.log(task)
    // })


    // db.collection('tasks').find({completed: false}).toArray((error, tasks) =>{
    //     console.log(tasks)
    // })


//    db.collection('users').updateOne({
//       _id: new ObjectID("5e73bcfe032f0e61189cc7e8")
//   },{
//      $inc:{
//          age : 4
//      }
//   }).then((result) =>{
//      console.log(result)
//  }).catch((error) =>{
//      console.log(error)
//  })


// db.collection('tasks').updateMany({completed: false},{
//     $set:{
//         completed: true
//     }
// }).then((result)=>{
//     console.log(result)
// }).catch((error)=>{
//     console.log(error)
// })


// db.collection('users').deleteMany({
//     age: 24
// }).then((result) =>{
     
//     console.log(result)

// }).catch((error) =>{

//     console.log(error)
// })


db.collection('tasks').deleteOne({ description : "Solve leetcode"}).then((result)=>{
    console.log(result)
}).catch((error)=>{
console.log(error)
})









})