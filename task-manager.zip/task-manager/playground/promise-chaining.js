require('../src/db/mongoose')
const User = require('../src/models/users')


// User.findByIdAndUpdate('5e76b1a3bb032428482914fc', {age:1}).then((user) =>{
//     console.log(user)
//     return User.countDocuments({age: 1})
// }).then((result) =>{
//     console.log(result)
// }).catch((error) =>{
//     console.log(error)
// })


const findAndUpdate = async(id, age) =>{

    const user = await User.findByIdAndUpdate(id, {age})
    const count = await User.countDocuments({age})
    return count
}

findAndUpdate('5e76b1a3bb032428482914fc',2).then((count) =>{
    console.log(count)
}).catch((e) =>{
    console.log(e)
})