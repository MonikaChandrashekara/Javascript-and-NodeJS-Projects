require('../src/db/mongoose')
const Task = require('../src/models/tasks')


// Task.findByIdAndDelete('5e768e2a8f05723d60529140').then((task)=>{

//     console.log(task)
//     return Task.countDocuments({completed: false})
// }).then((result) =>{
//     console.log(result)
// }).catch((e) =>{
//     console.log(e)
// })


const deleteTaskAndCount = async (id, completed) =>{

    const deletedDoc = await Task.findByIdAndDelete(id)
    const count = await Task.countDocuments({completed})
    return count
}

deleteTaskAndCount('5e76b403e381602814d7d475', false).then((count)=>{
    console.log(count)
}).catch((e)=>{
    console.log(e)
})