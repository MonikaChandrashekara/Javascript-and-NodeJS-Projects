console.log("utlis.js")


const add= function(a,b){
    return a+b
}




module.exports= add