const chalk= require('chalk')
const yargs= require('yargs')
const notes = require("./notes.js")

// const validtaor= require('validator')
// const notes= getNotes()
// console.log(notes)
// console.log(validtaor.isEmail('shekar.monika@gmail.com'))
// console.log(chalk.red('Error!'))

// console.log(process.argv[2])

// const command = process.argv[2]

// if(command==='add'){
//     console.log("Adding the note!")
// }else if(command==='remove'){
//     console.log("Removing the note!")
// }

//customize yargs version

yargs.version('1.1.0')

//command : creating add comand
yargs.command({

    command: 'add',
    describe: 'Add a new note',
    builder:{
       title:{
           describe: 'Add a title!',
           demandOption: true,
           type: 'string'
       },
       body:{
           describe: 'Add a body to the note',
           demandOption: true,
           type:'string'
       }
    },
    handler(argv){
       
        notes.addNote(argv.title,argv.body)
    }
})


//command: creating remove command 

yargs.command({

    command: 'remove',
    describe: 'Remove a note',
    builder:{
        title:{
            describe: 'Note title',
            demandOption: true,
            type: String
        }
    },
    handler(argv){
        notes.removeNotes(argv.title)
    }
})


//command: creating list command
yargs.command({
    command: 'list',
    describe: 'Listing the note',
    handler(){
        notes.listNotes()
    }
})

//command : creating read command 
yargs.command({
    command:'read',
    describe: 'Read notes',
    builder:{
        title:{
           describe: 'Provide the title',
           demandOption: true,
           style: String
        }
    },
    handler(argv){
        notes.readNote(argv.title)
    }
})


yargs.parse()
//console.log(yargs.argv)