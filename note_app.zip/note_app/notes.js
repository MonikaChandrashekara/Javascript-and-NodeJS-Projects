
const fs= require('fs')
const chalk= require('chalk')




const listNotes= () =>{

    const notes = loadNotes()

    console.log(chalk.inverse.yellow("Your notes!"))

    notes.forEach((note) =>{
        console.log(note.title)
    })
}

const addNote = (title, body) => {
   const note = loadNotes()
   
const duplicateNotes = note.find((singleNote) => singleNote.title===title) 

    debugger

   if(!duplicateNotes){
    note.push({
        title: title,
        body: body
    })
 
    saveNotes(note)
    console.log(chalk.green.inverse("New note added!"))
   }else{
       console.log(chalk.red.inverse("Note title already taken!"))
   }
   
}

const saveNotes = (note) =>{
 
    const dataJSON = JSON.stringify(note)
    fs.writeFileSync('notes.json',dataJSON)

}

const loadNotes = () =>{

    try{
         
        const dataBuffer = fs.readFileSync('notes.json')
        const dataJSON = dataBuffer.toString()
        return JSON.parse(dataJSON)

    }catch(e){
         return []
    }
}


const removeNotes = (title) =>{
     console.log("The note to be removed is " +title)

     const notes = loadNotes()

    

     const toSave = notes.filter((singleNote) => singleNote.title!==title)

    if(notes.length > toSave.length){
        saveNotes(toSave)
        console.log(chalk.green("note removed!"))
    }else{
        console.log(chalk.red("There is no note with that title found!"))
    }
    
}

const readNote = (title) =>{
          
    const notes = loadNotes()

    const Notes = notes.find((singleNote) => singleNote.title===title) 

    if(!Notes){
        console.log(chalk.inverse.red("No note with that title found!"))
    }else{

        console.log(chalk.bold.inverse.yellow('The tile: '+Notes.title))
        console.log(chalk.inverse('The body: '+Notes.body))
    }


}

module.exports= {

    
    addNote: addNote,
    removeNotes: removeNotes,
    listNotes: listNotes,
    readNote: readNote
}