const request = require('request')
const geocode = require('./utilis/geocode')
const forecast = require('./utilis/forecast')

// const url ='https://api.darksky.net/forecast/060afeb9458a1de0fdb528ae9bf18996/37.8267,-122.4233?units=si'



// request({url:url, json:true},(error,response)=>{
    
//     if(error){
//         console.log("unable to connect to the internet!")
//     }else if(response.body.error){
//         console.log("Unable to find the location!")
//     }
//     else{
//         console.log(response.body.daily.data[0].summary +"It is currently "+response.body.currently.temperature + " degrees out with an " +response.body.currently.precipProbability +"% chance of rain")
//     }
// })


// request({url: url_loc,json:true},(error,response)=>{

//     if(error){
//           console.log("unable to connect to the internet!")
//     }else if(response.body.features.length===0){
//         console.log("Please enter a valid location !")
//     }
//     else{
//         console.log(response.body.features[0].center[0] +" " +response.body.features[0].center[1])
//     }

    
// })


const address = process.argv[2]

if(!address){

    console.log("Please enter a valid address!")

}else{


    geocode(address, (error, {latitude,longitude,location})=>{
    
        if(error){
            return console.log(error)
        }
        
        forecast(latitude, longitude, (error, ForecastData) => {
           if(error){
            return console.log(error)
           } 
           
           console.log(location)
           console.log(ForecastData)
    
          })
    
    
    })
}






